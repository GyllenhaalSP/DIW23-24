document.addEventListener('DOMContentLoaded', function () {
    let bgm = document.getElementById("bgm");
    bgm.play();
});